var sample = [{
    "productName":"Tata Salt",
    "quantity":"1 Kg",
    "discountPrice":17,
    "originalPrice":19,
    "percentageOff":"10% OFF",
    "imageURL":"https://cdn.grofers.com/app/images/products/full_screen/pro_105.jpg",
    "productId":1,
    "saving":2,
    "productQuantity":null
  },
  {
    "productName":"Sugar",
    "quantity":"1 Kg",
    "discountPrice":39,
    "originalPrice":68,
    "percentageOff":"32% OFF",
    "imageURL":"https://cdn.grofers.com/app/images/products/full_screen/pro_39116.jpg",
    "productId":2,
    "saving":29,
    "productQuantity":null
  },
  {
    "productName":"Vim Lemon Dishwash Bar",
    "quantity":"120 gm",
    "discountPrice":10,
    "originalPrice":14,
    "percentageOff":"12% OFF",
    "imageURL":"https://cdn.grofers.com/app/images/products/full_screen/pro_12576.jpg",
    "productId":3,
    "saving":4,
    "productQuantity":null
  },
  {
    "productName":"Maggi Masala Noodles - Pack of 4",
    "quantity":"70 gm",
    "discountPrice":45,
    "originalPrice":48,
    "percentageOff":"6% OFF",
    "imageURL":"https://cdn.grofers.com/app/images/products/full_screen/pro_366837.jpg",
    "productId":5,
    "saving":3,
    "productQuantity":null
  },
  {
    "productName":"Fortune Sunlite Refined Sunflower Oil (Pouch)",
    "quantity":"1",
    "discountPrice":98,
    "originalPrice":125,
    "percentageOff":"21% OFF",
    "imageURL":"https://cdn.grofers.com/app/images/products/full_screen/pro_43.jpg",
    "productId":6,
    "saving":27,
    "productQuantity":null
  },
  {
    "productName":"Catch Turmeric Powder/Haldi",
    "quantity":"100 gm",
    "discountPrice":54,
    "originalPrice":43,
    "percentageOff":"20% OFF",
    "imageURL":"https://cdn.grofers.com/app/images/products/full_screen/pro_18857.jpg",
    "productId":7,
    "saving":11,
    "productQuantity":null
  }

];

  export default sample;